package com.orange.tpms.callback;

public interface textchange {
    void callback();
}
