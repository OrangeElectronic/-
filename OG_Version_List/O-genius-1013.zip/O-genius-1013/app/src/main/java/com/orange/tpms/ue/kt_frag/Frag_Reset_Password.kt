package com.orange.tpms.ue.kt_frag

import com.orange.jzchi.jzframework.JzFragement
import com.orange.tpms.R

//class Frag_Reset_Password:JzFragement(R.layout) {
//    override fun viewInit() {
//
//    }
//}