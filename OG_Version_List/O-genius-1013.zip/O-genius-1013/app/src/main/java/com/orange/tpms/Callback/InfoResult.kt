package com.orange.tpms.callback

interface InfoResult {
fun callback()
}