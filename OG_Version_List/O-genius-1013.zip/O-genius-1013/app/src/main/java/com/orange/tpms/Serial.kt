package com.orange.tpms

import com.jianzhi.glitter.JavaScriptInterFace

object Serial {
    var name="sql"
//   var storeText=JavaScriptInterFace("storeText") {
//       request ->
//         var file=
//   }
}