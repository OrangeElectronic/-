package com.orange.tpms.ue.kt_frag

import com.orange.jzchi.jzframework.JzFragement
import com.orange.tpms.R

class Frag_Program_Select:JzFragement(R.layout.layout_all_qustion) {
    override fun viewInit() {

    }
}