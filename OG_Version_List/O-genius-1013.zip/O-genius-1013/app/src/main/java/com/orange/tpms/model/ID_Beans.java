package com.orange.tpms.model;

public class ID_Beans {
    public String LF = "";
    public String RF = "";
    public String RR = "";
    public String LR = "";
    public String SP = "";
    public boolean success = false;

}
