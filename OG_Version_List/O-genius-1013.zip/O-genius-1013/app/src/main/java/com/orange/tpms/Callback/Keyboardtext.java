package com.orange.tpms.callback;

public interface Keyboardtext {
    void callback();
    void start(int a);
    void end(int a);
}
