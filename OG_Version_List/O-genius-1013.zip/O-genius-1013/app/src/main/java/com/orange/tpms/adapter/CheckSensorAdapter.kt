package com.orange.tpms.adapter

import com.orange.jzchi.jzframework.JzAdapter

//class CheckSensorAdapter(var a:ArrayList<Sensoritem>):JzAdapter() {
//    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
//
//    }
//
//    override fun sizeInit(): Int {
//        return a.size
//    }
//
//}
class Sensoritem(var id:String,var psi:String,var c:String,var bat:String)